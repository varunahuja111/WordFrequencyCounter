package com.acc.finalproject;

import java.io.BufferedReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;

import org.jsoup.Jsoup;

public class HtmlToTextConverter {
	private List<String> fileNames = new ArrayList<String>();

	private static ClassLoader getClassLoader() {
		return Thread.currentThread().getContextClassLoader();
	}

	public List<String> getResourceFileNames() {
		InputStream inputStream = getClassLoader().getResourceAsStream("W3C Web Pages");
		BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(inputStream));
		String fileName;

		try {
			int i = 1;// Remove this counter to read all Html files
			while ((fileName = bufferedReader.readLine()) != null && i <= 1) {
				fileNames.add(fileName);
				i++;
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
		return fileNames;
	}

	public void ConvertHtmlToText() {
		for (String fileName : fileNames) {
			InputStream inputStream = getClassLoader().getResourceAsStream("W3C Web Pages/" + fileName);
			InputStreamReader streamReader = new InputStreamReader(inputStream, StandardCharsets.UTF_8);
			BufferedReader bufferedReader = new BufferedReader(streamReader);

			StringBuilder fullText = new StringBuilder();
			String line = null;
			try {
				while ((line = bufferedReader.readLine()) != null) {
					fullText.append(line);
				}
				bufferedReader.close();
			} catch (IOException e) {
				e.printStackTrace();
			}

			String allText = fullText.toString();
			String plainText = Jsoup.parse(allText).text();
			String textFileName = fileName.replace(".htm", ".txt");

			try {
				// create new .txt file with the text of html
				FileWriter fileWriter = new FileWriter("src/main/resources/W3C Web Pages/Text/" + textFileName);
				fileWriter.write(plainText);
				fileWriter.close();

			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}
	public static void main(String[] args) {
		HtmlToTextConverter converter = new HtmlToTextConverter();
		converter.getResourceFileNames();
		converter.ConvertHtmlToText();
	}
}