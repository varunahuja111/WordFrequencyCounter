package com.acc.finalproject;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class PatternFinder {

	public void findWord(String word) throws IOException {
		File directory = new File("src/main/resources/W3C Web Pages/Text/");
		String[] fileNames = directory.list();
		int flag = 0;
		for (int i = 0; i < fileNames.length; i++) {
			try {
				File file = new File("src/main/resources/W3C Web Pages/Text/" + fileNames[i]);
				BufferedReader bufferedReader = new BufferedReader(new FileReader(file));
				String temp;
				String resultantString = new String();
				while ((temp = bufferedReader.readLine()) != null) {
					resultantString = temp;
				}
				String[] allLines = resultantString.split(" ");

				Pattern r = Pattern.compile(word);
				for (int j = 0; j < allLines.length; j++) {
					Matcher m = r.matcher(allLines[j]);
					while (m.find()) {
						flag = 1;
					}
				}
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		if (flag == 0) {
			System.out.println("Entered Word Not Found");
		} else {
			System.out.println("Entered Word: " + word + " found in HTML Files.");
		}
	}
}