package com.acc.finalproject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class WordFrequencyCounter {
	private List<String> fileNames = new ArrayList<String>();

	private static ClassLoader getClassLoader() {
		return Thread.currentThread().getContextClassLoader();
	}

	public List<String> getResourceFileNames() {
		InputStream inputStream = getClassLoader().getResourceAsStream("W3C Web Pages/Text");
		BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(inputStream));
		String fileName;

		try {
			while ((fileName = bufferedReader.readLine()) != null) {
				fileNames.add(fileName);
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
		return fileNames;
	}

	public Map<String, Integer> getWordFrequencyCount() {
		InputStream inputStream;
		Map<String, Integer> resultCount = new HashMap<String, Integer>();
		for (String fileName : fileNames) {
			inputStream = getClassLoader().getResourceAsStream("W3C Web Pages/Text/" + fileName);
			InputStreamReader streamReader = new InputStreamReader(inputStream, StandardCharsets.UTF_8);
			BufferedReader bufferedReader = new BufferedReader(streamReader);

			String word, content = null;
			try {
				while ((word = bufferedReader.readLine()) != null) {
					content = word;
				}
			} catch (IOException e) {
				e.printStackTrace();
			}
			String[] words = content.split(" ");
			int count = 0;
			for (String temp : words) {
				if (resultCount.containsKey(temp)) {
					count = resultCount.get(temp);
					count = count + 1;
					resultCount.replace(temp, resultCount.get(temp), count);
					count = 0;
				} else {
					resultCount.put(temp, ++count);
					count = 0;
				}
			}
		}
		return resultCount;
	}
}
