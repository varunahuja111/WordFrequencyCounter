package com.acc.finalproject;

import java.io.IOException;
import java.util.Map;
import java.util.Scanner;

public class WebSearchEngine {

	public static void main(String[] args) throws IOException {

		System.out.println("**********************************************************************************");
		System.out.println("*                             Web Search Engine                                  *");
		System.out.println("**********************************************************************************");
		int input = 0, count = 0;
		InitializeRequiredTextFiles();
		while (input != 3 || count == 0) {
			System.out.println();
			System.out.println("Enter an option:");
			System.out.println("1). Search for a Word.");
			System.out.println("2). Get Frequency of Words.");
			System.out.println("3). Exit");
			Scanner scanner = new Scanner(System.in);
			input = scanner.nextInt();
			count = 1;
			switch (input) {
			case 1: {
				System.out.println("Enter the Word to be Searched: \n");
				String text = scanner.next();
				PatternFinder patternFinder = new PatternFinder();
				patternFinder.findWord(text);
			}
				break;
			case 2: {
				WordFrequencyCounter wordFrequencyCounter = new WordFrequencyCounter();
				wordFrequencyCounter.getResourceFileNames();
				Map<String, Integer> wordFrequencyCount = wordFrequencyCounter.getWordFrequencyCount();
				for (String key : wordFrequencyCount.keySet()) {
					System.out.println("Key: " + key + "  Value: " + wordFrequencyCount.get(key));
				}
				break;
			}
			case 3:
				break;
			default:
				System.out.println("Enter a valid option!!!");
				break;
			}
		}
	}

	private static void InitializeRequiredTextFiles() {
		HtmlToTextConverter converter = new HtmlToTextConverter();
		converter.getResourceFileNames();
		converter.ConvertHtmlToText();
	}
}
